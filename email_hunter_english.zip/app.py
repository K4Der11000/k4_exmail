from flask import Flask, render_template, request, redirect, url_for, session, send_file
import re, os, time
from werkzeug.utils import secure_filename
from bs4 import BeautifulSoup

app = Flask(__name__)
app.secret_key = "your_secret_key"
UPLOAD_FOLDER = "uploads"
EMAIL_FILE = "emails.txt"
PASSWORD = "kader11000"

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def extract_emails_from_html(content):
    soup = BeautifulSoup(content, 'html.parser')
    text = soup.get_text()
    return set(re.findall(r"[\w\.-]+@[\w\.-]+", text))

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form.get("password") == PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/index")
def index():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("index.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/upload", methods=["POST"])
def upload():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    uploaded_files = request.files.getlist("html_files")
    all_emails = set()
    for file in uploaded_files:
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        with open(filepath, encoding="utf-8", errors="ignore") as f:
            content = f.read()
            emails = extract_emails_from_html(content)
            all_emails.update(emails)
    with open(EMAIL_FILE, "w") as f:
        for email in sorted(all_emails):
            f.write(email + "\n")
    return {"emails": sorted(all_emails), "count": len(all_emails)}

@app.route("/download")
def download():
    return send_file(EMAIL_FILE, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
