Email Hunter - by kader11000

How to run:
1. Install required packages:
   pip install flask beautifulsoup4

2. Run the application:
   python app.py

3. Open in your browser:
   http://127.0.0.1:5000

4. Password to access the tool: kader11000

Features:
- Extract emails from uploaded HTML files (offline).
- Save results to a file.
- Hacker-style interface with Matrix background.
- Flashing banner with your signature.
